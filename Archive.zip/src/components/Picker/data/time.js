import range from './range'

export default [range(0, 23, true, '点'), range(0, 59, true, '分'), range(0, 59, true, '秒')]
