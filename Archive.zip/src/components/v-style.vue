<script>
    export default {
        render(h) {
            return h('style', this.$slots.default);
        }
    }
</script>
