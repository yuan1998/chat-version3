<template>
    <div>

    </div>
</template>

<script>
    export default {
        props: {
            items: Array,
        }
    }
</script>

<style scoped>

</style>
