const isShowFooter = {}

export default isShowFooter;
